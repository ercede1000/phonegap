angular.module('WeatherApp.controllers.Main', [])

.controller('MainController', function($scope){
  
});